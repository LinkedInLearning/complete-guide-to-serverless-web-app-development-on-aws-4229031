export interface WaterIntake {
  id: string;
  amount: number; // in milliliters
  timestamp: Date;
  userId: string;
}